# Agent Meeting Room — Claude Code context

## What this project is
A Flask web app where multiple local AI agents (via Ollama) and Claude API
hold multi-agent conversations in a chat UI. Users @mention agents to summon them.

## Stack
- Python 3.11
- Flask (backend + SSE streaming)
- Ollama (local models: mistral, phi3, gemma2, deepseek)
- Anthropic Claude API (on-demand, for @claude only)
- Vanilla JS frontend (no frameworks)
- python-dotenv for config

## File responsibilities
- `app.py` — Flask routes, SSE streaming, request handling
- `agents.py` — Agent class definitions, Ollama + Claude API calls
- `memory.py` — Conversation history/context per agent
- `templates/index.html` — All frontend HTML/CSS/JS

## Rules
- NEVER hardcode API keys — always use os.getenv() with python-dotenv
- NEVER commit .env — it's in .gitignore
- Keep agent logic in agents.py, not in app.py
- Frontend is vanilla JS only — no npm, no frameworks
- All local models must be 7B parameters or smaller (RTX 4060 8GB limit)
- Claude API is only called when the user explicitly @mentions @claude

## Local environment
- Ollama runs at http://localhost:11434
- App runs at http://localhost:5000
- Windows machine, start with start.bat or `python app.py`

## Known issues being fixed
- SSE timing causing chat responses to not render in UI
- Obsidian vault note saving (in progress)
