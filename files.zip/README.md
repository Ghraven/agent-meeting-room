# Agent Meeting Room

> A local multi-agent AI collaboration platform where specialized AI agents hold structured discussions, debates, and free-form conversations — all running on your own hardware.

![Agent Meeting Room UI](docs/screenshot.png)

## What it does

You type a message, mention one or more agents, and they respond in real time. Each agent has a distinct personality and reasoning style. Claude acts as the "headmaster" — a more capable paid API agent brought in only when needed.

**Agents**
| Agent | Model | Role |
|-------|-------|------|
| @mistral | Mistral 7B | Analytical thinker |
| @phi3 | Phi-3 | Creative thinker |
| @gemma2 | Gemma 2 | Balanced summarizer |
| @deepseek | DeepSeek 7B | Deep reasoning |
| @claude | Claude API | Most capable — paid, on-demand |

**Modes**
- `@all` — summon all 4 local agents at once
- `@debate` — structured debate with rounds
- `@talk` — agents talk freely for 5 minutes

## Tech stack

- **Backend** — Python 3.11, Flask
- **AI (local)** — Ollama (Mistral, Phi-3, Gemma2, DeepSeek)
- **AI (cloud)** — Anthropic Claude API (on-demand only)
- **Frontend** — Vanilla HTML/CSS/JavaScript
- **Config** — python-dotenv

## Requirements

- Python 3.11+
- [Ollama](https://ollama.ai) installed and running
- At least one local model pulled (e.g. `ollama pull mistral`)
- Anthropic API key (optional — only needed for @claude)

## Setup

```bash
# 1. Clone the repo
git clone https://github.com/Ghraven/agent-meeting-room
cd agent-meeting-room

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set up environment variables
cp .env.example .env
# Open .env and add your Anthropic API key if you want @claude

# 4. Pull the local models you want to use
ollama pull mistral
ollama pull phi3
ollama pull gemma2
ollama pull deepseek-r1:7b

# 5. Start the app
python app.py
# or on Windows: start.bat
```

Visit **http://localhost:5000**

## Project structure

```
agent-meeting-room/
├── app.py              # Flask app, routes, SSE streaming
├── agents.py           # Agent definitions and Ollama/Claude API logic
├── memory.py           # Conversation memory management
├── templates/
│   └── index.html      # Frontend UI
├── .env.example        # Environment variable template
├── requirements.txt    # Python dependencies
└── start.bat           # Windows startup script
```

## How it works

1. User sends a message mentioning one or more agents (e.g. `@mistral explain black holes`)
2. Flask routes the request to `agents.py`
3. Each mentioned agent is called via Ollama's local API (or Claude API for @claude)
4. Responses stream back to the frontend via Server-Sent Events (SSE)
5. `memory.py` maintains conversation context per agent

## Hardware used

Built and tested on:
- GPU: NVIDIA RTX 4060 8GB
- RAM: 32GB
- All models are 7B parameters or smaller to fit in VRAM

## Status

Active development. Core multi-agent chat is working. Known issues being fixed:
- [ ] Chat responses not always rendering in UI (SSE timing issue)
- [ ] Notes save to Obsidian vault (in progress)

---

Built by [Rolly Calma](https://github.com/Ghraven) · Philippines
